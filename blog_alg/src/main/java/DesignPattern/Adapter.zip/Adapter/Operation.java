package com.css.alg.DesignPattern.Adapter;

public interface Operation {
    public void operation(String opType, int[]x);
}

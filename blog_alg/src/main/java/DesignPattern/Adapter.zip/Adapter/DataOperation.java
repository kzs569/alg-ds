package com.css.alg.DesignPattern.Adapter;

public interface DataOperation {
    public void sort(int[] array);
    public void search(int[] array);
}

from scrapy.cmdline import execute

#execute(['scrapy', 'crawl', 'csrcSpider'])
#execute(['scrapy', 'crawl', 'fnSpider'])
#execute(['scrapy', 'crawl', 'hxSpider'])
execute(['scrapy', 'crawl', 'fsSpider'])
